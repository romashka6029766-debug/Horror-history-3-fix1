# Horror Voice 3.0

Offline Android text-to-speech app based on Sherpa-ONNX v1.13.4.

## Features
- Russian Piper voices: Denis, Dmitri, Irina, Ruslan.
- Import a model folder through Android's file picker.
- Offline synthesis to WAV.
- Speed control.
- Horror post-processing: Normal, Dark, Demon, Whisper.
- Preview and share the generated WAV.
- No cloud API is required for synthesis.

## Model folders
For each voice, import the corresponding Sherpa-ONNX Piper model folder. The app expects the selected folder to contain a `.onnx` model, `tokens.txt`, and (for Piper models) `espeak-ng-data`.

Sherpa-ONNX's current examples list the Russian models `ru_RU-denis-medium`, `ru_RU-dmitri-medium`, `ru_RU-irina-medium`, and `ru_RU-ruslan-medium`.

## Build
- JDK 17
- Gradle 8.7
- Android Gradle Plugin 8.6.1
- compileSdk 35

The GitHub Actions workflow builds `app-debug.apk` and uploads it as an artifact.
