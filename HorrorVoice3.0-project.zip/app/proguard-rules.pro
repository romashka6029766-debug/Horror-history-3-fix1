# Horror Voice 3.0 intentionally keeps native Sherpa-ONNX symbols.
-keep class com.k2fsa.sherpa.onnx.** { *; }
