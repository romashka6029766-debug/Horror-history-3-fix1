package com.horrorvoice.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.content.FileProvider
import com.k2fsa.sherpa.onnx.*
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class MainActivity : Activity() {
    private lateinit var text: EditText
    private lateinit var voice: Spinner
    private lateinit var effect: Spinner
    private lateinit var speed: SeekBar
    private lateinit var speedLabel: TextView
    private lateinit var status: TextView
    private lateinit var generate: Button
    private lateinit var importModel: Button
    private lateinit var play: Button
    private lateinit var share: Button
    private var lastWav: File? = null
    private var player: MediaPlayer? = null

    private val voices = listOf(
        Voice("Денис", "ru_RU-denis-medium"),
        Voice("Дмитрий", "ru_RU-dmitri-medium"),
        Voice("Ирина", "ru_RU-irina-medium"),
        Voice("Руслан", "ru_RU-ruslan-medium")
    )
    private val effects = listOf("Обычный", "Тёмный", "Демон", "Шёпот")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
            setBackgroundColor(Color.rgb(16,16,16))
        }
        setContentView(root)

        val title = tv("HORROR VOICE 3.0", 26f, Color.WHITE).apply { setTypeface(typeface, 1); gravity = Gravity.CENTER }
        root.addView(title, lp(-1, -2))
        val sub = tv("Офлайн озвучка • Sherpa-ONNX", 13f, Color.LTGRAY).apply { gravity = Gravity.CENTER }
        root.addView(sub, lp(-1, -2, 0, 0, 0, 12))

        text = EditText(this).apply {
            hint = "Введите текст для озвучки…"
            setText("Когда наступает ночь, дом начинает говорить.")
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setBackgroundColor(Color.rgb(27,27,27))
            gravity = Gravity.TOP
            minLines = 7
            padding = dp(12)
        }
        root.addView(text, lp(-1, 0, 1f))

        root.addView(tv("Голос", 14f, Color.WHITE), lp(-1,-2,0,12,0,4))
        voice = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, voices.map { it.label })
        }
        root.addView(voice, lp(-1,-2))

        root.addView(tv("Эффект", 14f, Color.WHITE), lp(-1,-2,0,10,0,4))
        effect = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, effects)
        }
        root.addView(effect, lp(-1,-2))

        speedLabel = tv("Скорость: 1.00x", 14f, Color.WHITE)
        root.addView(speedLabel, lp(-1,-2,0,10,0,0))
        speed = SeekBar(this).apply {
            max = 100
            progress = 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = 0.5f + p / 100f
                    speedLabel.text = String.format(Locale.US, "Скорость: %.2fx", v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(speed, lp(-1,-2))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        importModel = btn("Импорт модели") { chooseModelFolder() }
        generate = btn("ОЗВУЧИТЬ") { synthesize() }
        row.addView(importModel, lp(0,-2,1f,0,6,0))
        row.addView(generate, lp(0,-2,1f,0,0,0))
        root.addView(row, lp(-1,-2,0,12,0,0))

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        play = btn("▶ Прослушать") { playLast() }.apply { isEnabled = false }
        share = btn("Поделиться") { shareLast() }.apply { isEnabled = false }
        row2.addView(play, lp(0,-2,1f,0,6,0))
        row2.addView(share, lp(0,-2,1f))
        root.addView(row2, lp(-1,-2,0,8,0,0))

        status = tv("Импортируй папку модели для выбранного голоса.", 13f, Color.LTGRAY)
        root.addView(status, lp(-1,-2,0,8,0,0))
    }

    private fun chooseModelFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, REQ_MODEL)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_MODEL || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) { }
        val v = voices[voice.selectedItemPosition]
        status.text = "Копирую модель ${v.label}…"
        generate.isEnabled = false
        Thread {
            try {
                val target = File(filesDir, "models/${v.id}").apply { deleteRecursively(); mkdirs() }
                copyTree(uri, target)
                runOnUiThread {
                    status.text = if (findOnnx(target) != null && File(target, "tokens.txt").exists())
                        "Модель ${v.label} готова. Можно озвучивать."
                    else "Не найден .onnx + tokens.txt в выбранной папке."
                    generate.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Ошибка импорта: ${e.message}"; generate.isEnabled = true }
            }
        }.start()
    }

    private fun synthesize() {
        val input = text.text.toString().trim()
        if (input.isEmpty()) { status.text = "Введите текст."; return }
        val v = voices[voice.selectedItemPosition]
        val root = File(filesDir, "models/${v.id}")
        val model = findOnnx(root)
        val tokens = File(root, "tokens.txt").takeIf { it.exists() } ?: findFile(root, "tokens.txt")
        if (model == null || tokens == null) {
            status.text = "Сначала импортируй папку модели ${v.label}."
            return
        }
        generate.isEnabled = false
        importModel.isEnabled = false
        status.text = "Синтезирую…"
        val baseSpeed = 0.5f + speed.progress / 100f
        val fx = effect.selectedItemPosition
        Thread {
            var tts: OfflineTts? = null
            try {
                val modelDir = model.parentFile ?: root
                val espeak = File(modelDir, "espeak-ng-data").takeIf { it.exists() }?.absolutePath ?: ""
                val cfg = OfflineTtsConfig(
                    model = OfflineTtsModelConfig(
                        vits = OfflineTtsVitsModelConfig(
                            model = model.absolutePath,
                            lexicon = "",
                            tokens = tokens.absolutePath,
                            dataDir = espeak,
                            lengthScale = 1.0f
                        ),
                        numThreads = 2,
                        debug = false,
                        provider = "cpu"
                    ),
                    maxNumSentences = 1,
                    silenceScale = 0.2f
                )
                tts = OfflineTts(config = cfg)
                val speedForFx = when (fx) { 2 -> baseSpeed * 0.78f; 3 -> baseSpeed * 1.08f; else -> baseSpeed }
                val audio = tts.generate(input, sid = 0, speed = speedForFx.coerceIn(0.35f, 1.8f))
                val processed = applyEffect(audio.samples, fx)
                val out = File(filesDir, "HorrorVoice_${System.currentTimeMillis()}.wav")
                writeWav(out, processed, audio.sampleRate)
                lastWav = out
                runOnUiThread {
                    status.text = "Готово: ${out.name}"
                    play.isEnabled = true
                    share.isEnabled = true
                    generate.isEnabled = true
                    importModel.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Ошибка синтеза: ${e.message ?: e.javaClass.simpleName}"
                    generate.isEnabled = true
                    importModel.isEnabled = true
                }
            } finally {
                try { tts?.release() } catch (_: Exception) {}
            }
        }.start()
    }

    private fun applyEffect(input: FloatArray, fx: Int): FloatArray {
        if (fx == 0) return input
        val out = input.copyOf()
        when (fx) {
            1 -> { // Dark: low-pass + mild gain
                var prev = 0f
                for (i in out.indices) {
                    prev += (out[i] - prev) * 0.055f
                    out[i] = (prev * 1.35f).coerceIn(-1f, 1f)
                }
            }
            2 -> { // Demon: saturation + tremolo
                for (i in out.indices) {
                    val trem = 0.78f + 0.22f * sin(i / 1700.0).toFloat()
                    out[i] = (kotlin.math.tanh(out[i] * 2.8f) * 0.92f * trem).coerceIn(-1f,1f)
                }
            }
            3 -> { // Whisper: strong attenuation + soft noise floor
                var seed = 0x12345678
                for (i in out.indices) {
                    seed = seed * 1664525 + 1013904223
                    val noise = ((seed ushr 8) and 0xFFFF) / 32768f - 1f
                    out[i] = (out[i] * 0.28f + noise * 0.012f).coerceIn(-1f,1f)
                }
            }
        }
        return out
    }

    private fun playLast() {
        val f = lastWav ?: return
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(f.absolutePath)
                prepare()
                start()
                setOnCompletionListener { it.release() }
            }
            status.text = "Воспроизведение…"
        } catch (e: Exception) { status.text = "Не удалось воспроизвести: ${e.message}" }
    }

    private fun shareLast() {
        val f = lastWav ?: return
        val uri = FileProvider.getUriForFile(this, "com.horrorvoice.app.fileprovider", f)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "audio/wav"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Поделиться WAV"))
    }

    private fun copyTree(treeUri: Uri, target: File) {
        val rootId = DocumentsContract.getTreeDocumentId(treeUri)
        copyChildren(DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, rootId), target)
    }

    private fun copyChildren(childrenUri: Uri, target: File) {
        val projection = arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE)
        contentResolver.query(childrenUri, projection, null, null, null)?.use { c ->
            val idI = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameI = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeI = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
            while (c.moveToNext()) {
                val id = c.getString(idI)
                val name = c.getString(nameI)
                val mime = c.getString(mimeI)
                val childUri = DocumentsContract.buildDocumentUriUsingTree(childrenUri, id)
                val safe = name.replace("/", "_")
                val out = File(target, safe)
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    out.mkdirs()
                    copyChildren(DocumentsContract.buildChildDocumentsUriUsingTree(childrenUri, id), out)
                } else {
                    contentResolver.openInputStream(childUri)?.use { input ->
                        BufferedInputStream(input).use { bin ->
                            FileOutputStream(out).use { fos -> BufferedOutputStream(fos).use { bout -> bin.copyTo(bout) } }
                        }
                    }
                }
            }
        }
    }

    private fun findOnnx(root: File): File? = root.walkTopDown().firstOrNull { it.isFile && it.extension.equals("onnx", true) }
    private fun findFile(root: File, name: String): File? = root.walkTopDown().firstOrNull { it.isFile && it.name == name }

    private fun writeWav(file: File, samples: FloatArray, sampleRate: Int) {
        val dataSize = samples.size * 2
        BufferedOutputStream(FileOutputStream(file)).use { out ->
            fun s(v: String) = out.write(v.toByteArray(Charsets.US_ASCII))
            fun i32(v: Int) { out.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v).array()) }
            fun i16(v: Int) { out.write(ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort(v.toShort()).array()) }
            s("RIFF"); i32(36 + dataSize); s("WAVEfmt "); i32(16); i16(1); i16(1); i32(sampleRate); i32(sampleRate * 2); i16(2); i16(16); s("data"); i32(dataSize)
            for (x in samples) i16((x.coerceIn(-1f, 1f) * 32767f).toInt())
        }
    }

    private fun tv(s: String, size: Float, color: Int) = TextView(this).apply { text = s; textSize = size; setTextColor(color) }
    private fun btn(s: String, action: () -> Unit) = Button(this).apply { text = s; setOnClickListener { action() } }
    private fun lp(w: Int, h: Int, weight: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) = LinearLayout.LayoutParams(w, h, weight).apply { setMargins(dp(l),dp(t),dp(r),dp(b)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        player?.release()
        super.onDestroy()
    }

    data class Voice(val label: String, val id: String)

    companion object { const val REQ_MODEL = 1001 }
}
